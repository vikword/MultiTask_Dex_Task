﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace MultiTask_Dex_Task
{
    interface IJobExecutor
    {
        // Кол-во задач в очереди на обработку
        int Amount { get; }

        // Запустить обработку очереди и установить максимальное кол-во параллельных задач
        void Start(int maxConcurrent);

        void Stop();

        // Добавить задачу в очередь
        void Add(Action action);

        // Очистить очередь задач
        void Clear();
    }

    class JobExecutor : IJobExecutor
    {
        private class JobItem
        {
            private readonly Action _action;
            private readonly JobExecutor _jobExecutor;

            public JobItem(Action action, JobExecutor jobExecutor)
            {
                _action = action;
                _jobExecutor = jobExecutor;
            }

            public void ExecuteJob()
            {
                try
                {
                    _jobExecutor.Semaphore.Wait(_jobExecutor.CancellationToken);
                    _action.Invoke();
                }
                catch (OperationCanceledException)
                {
                    Console.WriteLine("Задача была отменена, дальнейшая работа не будет произведена");
                    //Console.WriteLine(ex.Message);
                }
                catch (ObjectDisposedException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    _jobExecutor.Semaphore.Release();
                }

                //_jobExecutor.Semaphore.Wait();
                //
                //if (_jobExecutor.CancellationToken.IsCancellationRequested)
                //{
                //    Console.WriteLine("Задача была отменена, дальнейшая работа не будет произведена");
                //
                //    return;
                //}
                //_action.Invoke();
                //_jobExecutor.Semaphore.Release();
            }
        }
        private uint _countTaskStart = 0;
        public int Amount => _tasks.Count;
        public SemaphoreSlim Semaphore { get; private set; }

        private readonly ConcurrentQueue<JobItem> _tasks = new();

        private readonly CancellationTokenSource _tokenSource;

        private readonly CancellationToken _cancellationToken;
        public CancellationToken CancellationToken => _cancellationToken;

        public JobExecutor()
        {
            _tokenSource = new CancellationTokenSource();
            _cancellationToken = _tokenSource.Token;
        }

        public void Add(Action action)
        {
            _tasks.Enqueue(new JobItem(action, this));
        }

        public void Clear()
        {
            Console.WriteLine($"Очередь из {Amount} задач очищена. Выполняются запущенные ранее {_countTaskStart} задач\n");
            _tasks.Clear();
            _countTaskStart = 0;
        }

        public void Start(int maxConcurrent)
        {
            Semaphore = new SemaphoreSlim(maxConcurrent);

            while (_tasks.TryDequeue(out var task))
            {
                Console.WriteLine(++_countTaskStart);
                Task.Factory.StartNew(() => task.ExecuteJob());
                //task.ExecuteJob();
            }
        }

        public void Stop()
        {
            _tokenSource.Cancel();
            Console.WriteLine($"Обработка очереди остановлена.");
        }
    }

    public class TestClass
    {
        public void Test()
        {
            Console.WriteLine($"Начало работы задачи. Id задачи {Task.CurrentId}, #Thread {Thread.CurrentThread.ManagedThreadId}");
            Thread.Sleep(2000);
            Console.WriteLine($"Конец работы задачи. Id задачи {Task.CurrentId}, #Thread {Thread.CurrentThread.ManagedThreadId}");
        }
    }
    class Program
    {
        static void Main()
        {
            var job = new JobExecutor();

            for (int i = 0; i < 20; i++)
            {
                job.Add(() => new TestClass().Test());
            }

            Task.Factory.StartNew(() => job.Start(2));
            //job.Start(2);
            Thread.Sleep(1);
            job.Clear();
            Thread.Sleep(2000);

            //job.Clear();
            job.Stop();

            Console.ReadKey();
        }
    }
}

